from django.contrib import admin

from .models import ChatHistory, User

admin.site.register(ChatHistory)
admin.site.register(User)

